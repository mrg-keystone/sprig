# impeccable (vendored) + design-lint

A self-contained design-quality toolkit for AI coding agents, packaged for a
Deno toolchain with **no npm package to install**. Two pieces that ship together:

```
mock-skill/
├── skill/impeccable/     The impeccable skill (SKILL.md + reference/ + scripts/)
│                         — model-invoked design playbooks (craft, critique,
│                           audit, polish, live, init, …). Drop into a harness
│                           skills dir to activate.
└── design-lint/          Standalone Deno linter (the detection engine, ported
                          from impeccable, Puppeteer→Astral). The single source
                          of truth for anti-pattern detection.
```

Both are derived from [impeccable](https://github.com/pbakaus/impeccable)
(Apache-2.0). See `design-lint/NOTICE` for attribution and the list of changes.

## How the two connect

The skill never bundles its own detector. Its detection entrypoint
(`skill/impeccable/scripts/detect.mjs`) forwards to `design-lint`:

```
agent → node …/skill/impeccable/scripts/detect.mjs --json <targets>
      → deno run …/design-lint/bin/detect.mjs <targets>
      → detection engine (static files, or live URL via Astral)
```

`detect.mjs` finds `design-lint` by, in order:
1. `$DESIGN_LINT_BIN` — absolute path to `design-lint/bin/detect.mjs`
2. `$DESIGN_LINT_DIR` — the `design-lint/` checkout
3. walking up from the skill for a sibling `design-lint/` (works out of the box
   in this package layout)

## Requirements

- **Deno** on `PATH` (tested with 2.7). Static scans need nothing else; live
  URL scans download Chromium on first run via Astral.
- **Node** on `PATH` only because the agent invokes `node …/detect.mjs`; that
  wrapper just spawns Deno. (If you prefer, call `deno run …/design-lint/bin/detect.mjs`
  directly and skip Node entirely.)

## Install into a harness

Copy the skill into a project's skills dir and keep `design-lint` reachable:

```sh
./install.sh /path/to/your/project        # installs to <project>/.claude/skills/impeccable
```

If you install the skill somewhere the walk-up can't reach `design-lint`
(more than ~8 parent dirs away), export `DESIGN_LINT_DIR=/abs/path/design-lint`
in the environment your agent runs under.

## Use the linter directly (CI / scripts)

```sh
cd design-lint
deno task lint src/                     # static scan, exit 2 on findings
deno task lint --json src/              # machine-readable
deno task lint:url https://example.com  # full browser scan
```
